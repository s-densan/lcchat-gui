# neutralinojs-typescript

Typescript starter project for Neutralinojs

## Get started

Clone the repo 

```bash
$ git clone https://github.com/neutralinojs/neutralinojs-typescript.git
$ cd neutralinojs-typescript
```

Install dependencies 

```bash
$ npm i
```

Bundle source files

```bash
$ npm run build
```
      
