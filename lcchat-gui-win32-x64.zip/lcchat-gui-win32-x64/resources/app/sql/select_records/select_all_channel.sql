SELECT
    channel_id,
    channel_name,
    room_id,
    channel_data,
    created_at,
    updated_at,
    deleted_at
FROM
    channel



