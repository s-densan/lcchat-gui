SELECT
    user_id,
    user_name,
    user_data,
    created_at,
    updated_at,
    deleted_at
FROM user
