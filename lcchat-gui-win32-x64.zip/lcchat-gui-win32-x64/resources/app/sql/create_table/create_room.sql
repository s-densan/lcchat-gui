CREATE TABLE IF NOT EXISTS room (
    room_id varchar(64),
    room_name varchar(64),
    room_data varchar(1024)
)

